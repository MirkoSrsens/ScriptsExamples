﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DiContainerLibrary;
using DiContainerLibrary.DiContainer;

namespace TestClass
{
    class Program
    {
        static void Main(string[] args)
        {
            var section = ConfigurationManager.GetSection("DiContainerInitialization");
            if (section != null)
            {
                var sectionConf = section as DiContainerSectionReader;
                var item = (section as DiContainerSectionReader).Collection;
                item.RegisterFromConfiguration();

                var harbor = new Harbor()
                {
                    Number = 101
                };

                var container = TestClassForDiContainer.InitializeContainer();
                var container2 = TestClassForDiContainer.InitializeContainer();
                var container3 = TestClassForDiContainer.InitializeContainer();

                container.Bind<IStorage>().To<Harbor>();

                TestClassForDiContainer.RegisterContainer(container);
            }

            var testClass = new TestAttribute();
            var register = TestClassForDiContainer.CreateProperty<IStorage>();
            var airport = TestClassForDiContainer.CreateInstanceUsingConstructor<Airport>();
            var airport2 = TestClassForDiContainer.CreateInstanceUsingConstructor<Airport>(new System.Collections.Generic.List<Type>() { typeof(IStorage), typeof(Harbor) });

        }
    }
}
