﻿using System;

namespace DiContainerLibrary.DiContainer
{
    public class InjectDiContainter : Attribute
    {
        public string Id { get; set; }

        public InjectDiContainter(string id = null)
        {
            this.Id = id;
        }
    }
}
