﻿using System;
using System.Collections.Generic;
using System.Configuration;

namespace DiContainerLibrary.DiContainer
{
    [ConfigurationCollection(typeof(DiContainerElementReader))]
    public class DiContainerCollectionReader : ConfigurationElementCollection
    {
        internal const string PropertyName = "injectionDefinition";

        protected override string ElementName { get { return PropertyName; } }

        public override ConfigurationElementCollectionType CollectionType
        {
            get
            {
                return ConfigurationElementCollectionType.BasicMapAlternate;
            }
        }

        protected override bool IsElementName(string elementName)
        {
            return elementName == PropertyName;
        }

        public override bool IsReadOnly()
        {
            return false;
        }

        protected override ConfigurationElement CreateNewElement()
        {
            return new DiContainerElementReader();
        }

        protected override object GetElementKey(ConfigurationElement element)
        {
            return ((DiContainerElementReader)element).UniqueIdentifier;
        }

        public DiContainerElementReader this[int index]
        {
            get
            {
                return (DiContainerElementReader)BaseGet(index);
            }
        }
    }
}
