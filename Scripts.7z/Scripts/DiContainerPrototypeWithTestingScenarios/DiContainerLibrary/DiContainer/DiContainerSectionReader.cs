﻿using System.Configuration;

namespace DiContainerLibrary.DiContainer
{
    public class DiContainerSectionReader : ConfigurationSection
    {
        [ConfigurationProperty("Container")]
        public DiContainerCollectionReader Collection
        {
            get { return ((DiContainerCollectionReader)(base["Container"])); }
            set { base["Container"] = value; }
        }
    }
}
