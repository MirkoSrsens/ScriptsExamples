﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Text;

namespace DiContainerLibrary.DiContainer
{
    public class DiContainerElementReader : ConfigurationElement
    {
        private const string BindName = "Bind";
        private const string ToName = "To";
        private const string IsLazyName = "IsLazy";
        private const string IdName = "Id";
        private const string IsSingleName = "IsSingle";
        private const string IsStaticName = "IsStatic";
        private const string IsPriorityName = "IsPriority";

        public Guid UniqueIdentifier { get { return Guid.NewGuid(); } }

        [ConfigurationProperty(BindName, IsRequired = true)]
        public string Bind { get { return (string)this[BindName]; } set { this[BindName] = value; } }

        [ConfigurationProperty(ToName, IsRequired = true)]
        public string To { get { return (string)this[ToName]; } set { this[ToName] = value; } }

        [ConfigurationProperty(IdName)]
        public string Id { get { return (string)this[IdName]; } set { this[IdName] = value; } }

        [ConfigurationProperty(IsLazyName)]
        public bool IsLazy { get { return (bool)this[IsLazyName]; } set { this[IsLazyName] = value; } }

        [ConfigurationProperty(IsSingleName)]
        public bool IsSingle { get { return (bool)this[IsSingleName]; } set { this[IsSingleName] = value; } }

        [ConfigurationProperty(IsStaticName)]
        public bool IsStatic { get { return (bool)this[IsStaticName]; } set { this[IsStaticName] = value; } }

        [ConfigurationProperty(IsPriorityName)]
        public bool IsPriority { get { return (bool)this[IsPriorityName]; } set { this[IsPriorityName] = value; } }
    }
}
