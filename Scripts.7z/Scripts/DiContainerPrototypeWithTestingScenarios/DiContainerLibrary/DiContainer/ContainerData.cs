﻿using System;

namespace DiContainerLibrary.DiContainer
{
    public class ContainerData
    {
        /// <summary>
        /// Gets or sets uniques identifier of the identifier.
        /// </summary>
        public string Id { get; set; }

        /// <summary>
        /// Gets or sets data type.
        /// </summary>
        public Type dataType { get; set; }

        /// <summary>
        /// Gets or sets actual value.
        /// </summary>
        public object actualValue { get; set; }

        /// <summary>
        /// gets or sets value indicating is property static.
        /// </summary>
        public bool IsStatic { get; set; }

        /// <summary>
        /// Gets or sets value indicating is this property lazy loaded.
        /// </summary>
        public bool IsLazy { get; set; }

        /// <summary>
        /// Gets or sets value indicating is this injection priority.
        /// </summary>
        public bool IsPriority { get; set; }
    }
}
