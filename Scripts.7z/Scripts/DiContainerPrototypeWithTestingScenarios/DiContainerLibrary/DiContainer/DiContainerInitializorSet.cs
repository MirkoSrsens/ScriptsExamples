﻿using System;
using System.Collections.Generic;

namespace DiContainerLibrary.DiContainer
{
    public static partial class TestClassForDiContainer
    {
        /// <summary>
        /// Gets or sets dictionary container that will store information about injections.
        /// </summary>
        private static Dictionary<Type, List<ContainerData>> Container = new Dictionary<Type, List<ContainerData>>();

        /// <summary>
        /// Initializes new container.
        /// </summary>
        /// <returns>The container that will be used for initialization.</returns>
        public static Dictionary<Type, List<ContainerData>> InitializeContainer()
        {
            return new Dictionary<Type, List<ContainerData>>();
        }

        /// <summary>
        /// Registers container for usage.
        /// </summary>
        /// <param name="data"></param>
        public static void RegisterContainer(this Dictionary<Type, List<ContainerData>> data)
        {
            foreach(var item in data)
            {
                if (!Container.ContainsKey(item.Key))
                {
                    Container.Add(item.Key, item.Value);
                }
                else
                {
                    Container[item.Key].AddRange(item.Value);
                }
            }
        }

        public static void RegisterFromConfiguration(this DiContainerCollectionReader collection)
        {
            var container = new Dictionary<Type, List<ContainerData>>();
            for (int i = 0; i < collection.Count; i++)
            {
                var bindType = Type.GetType(collection[i].Bind);
                var toType = Type.GetType(collection[i].To);

                var result = new ContainerData()
                {
                    dataType = toType,
                    Id = collection[i].Id,
                    IsLazy = collection[i].IsLazy,
                    IsStatic = collection[i].IsSingle,
                    IsPriority = collection[i].IsPriority
                };

                if(!container.ContainsKey(bindType))
                {
                    container.Add(bindType, new List<ContainerData>());
                }
                container[bindType].Add(result);
            }

            container.RegisterContainer();
        }

        /// <summary>
        /// Defines interface that will be used for binding.
        /// </summary>
        /// <typeparam name="TInterface">The type of interface.</typeparam>
        /// <returns>Interface type.</returns>
        public static List<ContainerData> Bind<TInterface>(this Dictionary<Type, List<ContainerData>> container)
            where TInterface : class
        {
            var type = typeof(TInterface);
            if (!container.ContainsKey(type))
            {
                container.Add(typeof(TInterface), new List<ContainerData>());
            }
            return container[type];
        }

        /// <summary>
        /// Defines class that will be used for defining interface.
        /// </summary>
        /// <typeparam name="TClass">Class that will be used for binding.</typeparam>
        /// <param name="function"></param>
        /// <returns></returns>
        public static ContainerData To<TClass>(this List<ContainerData> containerData, TClass ActualValue = null)
            where TClass : class
        {
            var result = new ContainerData()
            {
                dataType = typeof(TClass),
                IsStatic = false,
                IsLazy = false,
                IsPriority = false,
            };

            if(ActualValue != null)
            {
                result.actualValue = ActualValue;
                result.IsStatic = true;
            }

            containerData.Add(result);
            return result;
        }

        /// <summary>
        /// Defines data as singleton.
        /// </summary>
        /// <param name="data">The data to assign.</param>
        /// <returns></returns>
        public static ContainerData AsSingle(this ContainerData data)
        {
            data.IsStatic = true;

            return data;
        }

        /// <summary>
        /// Defines data as transient.
        /// </summary>
        /// <param name="data">The data to assign.</param>
        /// <returns></returns>
        public static ContainerData AsTransient(this ContainerData data)
        {
            if (data.actualValue == null)
            {
                data.IsStatic = false;
            }

            return data;
        }

        /// <summary>
        /// Defines data as lazy.
        /// </summary>
        /// <param name="data">The data to assign.</param>
        /// <returns></returns>
        public static ContainerData Lazy(this ContainerData data)
        {
            data.IsLazy = true;

            return data;
        }

        /// <summary>
        /// Defines data as non lazy.
        /// </summary>
        /// <param name="data">The data to assign.</param>
        /// <returns></returns>
        public static ContainerData NonLazy(this ContainerData data)
        {
            data.IsLazy = false;

            return data;
        }

        /// <summary>
        /// Sets data as priority for injection.
        /// </summary>
        /// <param name="data">The data to assign.</param>
        /// <returns></returns>
        public static ContainerData SetPriority(this ContainerData data)
        {
            data.IsPriority = true;

            return data;
        }

        /// <summary>
        /// Sets data id for injection.
        /// </summary>
        /// <param name="data">The data to assign.</param>
        /// <returns></returns>
        public static ContainerData SetId(this ContainerData data, string Id)
        {
            data.Id = Id;

            return data;
        }
    }
}
