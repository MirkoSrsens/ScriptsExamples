﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using DiContainerLibrary.Properties;

namespace DiContainerLibrary.DiContainer
{
    public static partial class TestClassForDiContainer
    {
        /// <summary>
        /// Gets injection definition for given interface,
        /// </summary>
        /// <typeparam name="TInterface">Interface to inject.</typeparam>
        /// <param name="Id">The identifier of interface.</param>
        /// <param name="typeOfInstance">The type of instance.</param>
        /// <returns></returns>
        public static TInterface CreateProperty<TInterface>(string Id = null, Type typeOfInstance = null)
          where TInterface : class
        {
            var key = typeof(TInterface);

            if(!Container.ContainsKey(key))
            {
                throw new KeyNotFoundException();
            }

            var containerData = Container[typeof(TInterface)];

            var result = ValidateContainerData(containerData, Id, typeOfInstance);

            if (result == null)
            {
                throw new ArgumentException(Strings.Error_NoValidInstanceFoundForContainer);
            }

            return (TInterface)result;
        }

        /// <summary>
        /// Registers all dependencies of the given object.
        /// </summary>
        /// <param name="objectToinitialize">The object with dependency</param>
        public static void CreateInstanceUsingObject(this object objectToinitialize)
        {
            var properties = objectToinitialize.GetType().GetProperties()
                    .Where(prop => prop.IsDefined(typeof(InjectDiContainter), false)).ToList();

            foreach (var property in properties)
            {
                // Gets attribute id
                var injectionId = (property.GetCustomAttributes(false).SingleOrDefault() as InjectDiContainter).Id;

                // Gets type of property.
                var getType = property.PropertyType;
                if (!getType.IsGenericType)
                {
                    property.SetValue(objectToinitialize, getType.RegisterPropertyOfObject(injectionId));
                }
                // In case we are injecting generic property (List,IEnumerable etc...)
                else
                {
                    var casted = getType.GetGenericArguments().Single().RegisterCollection();
                    property.SetValue(objectToinitialize, casted);
                }
            }
        }

        /// <summary>
        /// Creates new instance using constructor injection.
        /// </summary>
        /// <typeparam name="TClass">Class that will be created with injection.</typeparam>
        /// <returns></returns>
        public static TClass CreateInstanceUsingConstructor<TClass>()
            where TClass : class
        {
            var constructor = typeof(TClass).GetConstructors().FirstOrDefault();

            if (constructor != null)
            {
                var parameters = constructor.GetParameters();

                var parameterArgs = new List<object>();

                foreach (var param in parameters)
                {
                    parameterArgs.Add(param.RegisterConstructorProperty());
                }
                return (TClass)Activator.CreateInstance(typeof(TClass), parameterArgs.ToArray());
            }
            else
            {
                throw new ArgumentNullException();
            }
        }

        /// <summary>
        /// Creates new instance using constructor injection.
        /// </summary>
        /// <typeparam name="TClass">Class that will be created with injection.</typeparam>
        /// <returns></returns>
        public static TClass CreateInstanceUsingConstructor<TClass>(List<Type> specificConstructorParameters)
            where TClass : class
        {
            var constructor = typeof(TClass).GetConstructors()
                .Where(x=> x.GetParameters()
                .Select(y=> y.ParameterType)
                .All(z=> specificConstructorParameters.Contains(z)))
                .SingleOrDefault();

            if (constructor != null)
            {
                var parameters = constructor.GetParameters();

                var parameterArgs = new List<object>();

                foreach (var param in parameters)
                {
                    parameterArgs.Add(param.RegisterConstructorProperty());
                }
                return (TClass)Activator.CreateInstance(typeof(TClass), parameterArgs.ToArray());
            }
            else
            {
                throw new ArgumentNullException();
            }
        }

        /// <summary>
        /// Creates instance of a new object using container data.
        /// </summary>
        /// <param name="data">The data you want to instantiate.</param>
        /// <returns></returns>
        private static object CreateInstance(ContainerData data)
        {
            var instance = Activator.CreateInstance(data.dataType);
            if (data.IsStatic)
            {
                if (data.actualValue == null)
                {
                    data.actualValue = instance;
                }
                return data.actualValue;
            }
            else
            {
                return instance;
            }
        }

        /// <summary>
        /// Registers property type object.
        /// </summary>
        /// <param name="data">The data type.</param>
        /// <returns>Returns registered object.</returns>
        private static object RegisterPropertyOfObject(this Type data, string injectionId = null)
        {
            var containerData = Container[data];

            var selectedData = containerData.SingleOrDefault(x => !string.IsNullOrEmpty(injectionId) && x.Id == injectionId);

            if (selectedData == null)
            {
                selectedData = containerData.SingleOrDefault(x => x.IsPriority);

                // If there is no priority class check if there is only one initialization.
                if (selectedData == null)
                {
                    if (containerData.Count == 1)
                    {
                        selectedData = containerData[0];
                    }
                    else
                    {
                        throw new NotImplementedException();
                    }
                }
            }
            if (selectedData.IsLazy)
            {
                return null;
            }
            return CreateInstance(selectedData);
        }

        /// <summary>
        /// Registers collection type object.
        /// </summary>
        /// <param name="type">The type of collection to register.</param>
        /// <returns></returns>
        private static IList RegisterCollection(this Type type)
        {
            var containerData = Container[type];

            Type listType = typeof(List<>).MakeGenericType(new[] { type });
            var result = (IList)Activator.CreateInstance(listType);

            foreach (var item in containerData)
            {
                if (item.IsLazy)
                {
                    continue;
                }

                var instance = Activator.CreateInstance(item.dataType);

                if (item.IsStatic)
                {
                    if (item.actualValue == null)
                    {
                        item.actualValue = instance;
                    }
                    result.Add(item.actualValue);
                }
                else
                {
                    result.Add(instance);
                }
            }

            return result;
        }

        /// <summary>
        /// Registers all dependencies of the given object.
        /// </summary>
        /// <param name="objectToinitialize">The object with dependency</param>
        private static object RegisterConstructorProperty(this ParameterInfo objectToinitialize)
        {
            var containerData = Container[objectToinitialize.ParameterType];
            var instance = ValidateContainerData(containerData);

            if(instance != null)
            {
                return instance;
            }

            throw new ArgumentException(Strings.Error_NoValidInstanceFoundForContainer);

        }

        private static object ValidateContainerData(List<ContainerData> containerData, string Id = null, Type typeOfInstance = null)
        {
            if (Id != null)
            {
                var containerDataWithId = containerData.Where(x => x.Id == Id);

                if (containerDataWithId.Count() > 1)
                {
                    throw new ArgumentException();
                }
                else if (containerData.Count() == 1)
                {
                    return CreateInstance(containerDataWithId.SingleOrDefault());
                }
            }

            // If type of specific instance is assigned.
            if (typeOfInstance != null)
            {
                var priorityInitialization = containerData.SingleOrDefault(x => x.dataType == typeOfInstance);

                if (priorityInitialization != null)
                {
                    return CreateInstance(priorityInitialization);
                }
            }
            // If container only holds one instance of object.
            else if (Container.Count == 1)
            {
                return CreateInstance(containerData[0]);
            }
            // If there is instance with priority.
            else if (containerData.Count > 1)
            {
                var priorityInitialization = containerData.SingleOrDefault(x => x.IsPriority);

                if (priorityInitialization != null)
                {
                    return CreateInstance(priorityInitialization);
                }
            }

            return null;
        }
    }
}
