﻿using System;

namespace DiContainerLibrary
{
    public class Harbor : IStorage
    {
        public int Number { get; set; }

        public Harbor()
        {
            Random random = new Random();
            Number = random.Next(0, 1000);
        }
    }
}
