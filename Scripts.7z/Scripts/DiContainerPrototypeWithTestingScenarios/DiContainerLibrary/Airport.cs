﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiContainerLibrary
{
    public class Airport
    {
        public IStorage storage { get; set; }

        public Airport(IStorage storage)
        {
            this.storage = storage;
        }
    }
}
