﻿using System;
using DiContainerLibrary.DiContainer;

namespace DiContainerLibrary
{
    public class Storage : IStorage
    {
        public int Number { get; set; }

        public Storage()
        {
            Random random = new Random();
            Number = random.Next(0, 1000);
        }
    }
}
