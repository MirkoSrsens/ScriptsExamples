﻿using System.Collections.Generic;
using DiContainerLibrary.DiContainer;

namespace DiContainerLibrary
{
    public class TestAttribute
    {
        [InjectDiContainter]
        public List<IStorage> storage { get; set; }

        [InjectDiContainter("Test")]
        public IStorage storageSingle { get; set; }

        public TestAttribute()
        {
            this.CreateInstanceUsingObject();
        }
    }
}
