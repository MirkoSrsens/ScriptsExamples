﻿using System;
using System.Linq;
using UnityEngine;

namespace Implementation.Data
{
    /// <summary>
    /// Holds implementation of <see cref="IEnemyData"/>.
    /// </summary>
    [Serializable]
    public class EnemyData : IEnemyData
    {
        /// <inheritdoc />
        public string Id { get; set; }

        /// <inheritdoc/>
        public float RangeOfVision { get; set; }

        /// <inheritdoc/>
        public float AngleOfVisionHigher { get; set; }

        /// <inheritdoc/>
        public float AngleOfVisionLower { get; set; }

        /// <inheritdoc/>
        public float RangeOfAttack { get; set; }

        /// <inheritdoc/>
        public bool CanAttack { get; set; }

        /// <inheritdoc/>
        public float AttackCooldown { get; set; }

        /// <inheritdoc/>
        public int Damage { get; set; }

        /// <inheritdoc/>
        public bool IsTargetDetected(Transform character, Transform target)
        {
            var result = Physics2D.OverlapBoxAll(new Vector2(character.position.x + (character.localScale.x * RangeOfVision / 2), character.position.y), new Vector2(RangeOfVision *character.transform.localScale.x, character.transform.localScale.y), 0);
            return result.Select(x => x.gameObject).ToList().Contains(target.gameObject);
        }

        /// <inheritdoc/>
        public bool NotSneakingRangeOfDetection(Transform character, Transform target)
        {
            if (Physics2D.OverlapCircleAll(character.position, RangeOfVision/3).Select(x => x.gameObject).Contains(target.gameObject))
            {
                return true;
            }

            return false;
        }

        /// <inheritdoc/>
        public bool IsTargetStillInRangeOfVision(Transform character, Transform target)
        {
            if (Physics2D.OverlapCircleAll(character.position, RangeOfVision).Select(x => x.gameObject).Contains(target.gameObject))
            {
                RaycastHit2D hit = Physics2D.Raycast(character.transform.position, target.transform.position - character.transform.position);

                if (hit.transform != null && hit.transform.gameObject.tag == target.transform.tag)
                {
                    return true;
                }
            }

            return false;
        }

        /// <inheritdoc/>
        public bool IsTargetInRangeOfAttack(Transform character, Transform target)
        {
            if (Physics2D.OverlapCircleAll(character.position, RangeOfAttack).Select(x => x.gameObject).Contains(target.gameObject))
            {
                return true;
            }
            return false;
        }

        /// <inheritdoc/>
        public int LookAtTarget(Transform character, Transform target)
        {
            var roationAngle = target.position.x - character.position.x;

            //// Proper rotation
            if (roationAngle < 0)
            {
                character.localScale = new Vector3(-1, 1, 1);
            }
            else
            {
                character.localScale = new Vector3(1, 1, 1);
            }

            if (Vector2.Distance(new Vector2(target.transform.position.x, 0), new Vector2(character.transform.position.x, 0)) < RangeOfAttack / 2)
            {
                return 0;
            }

            return roationAngle > 0 ? 1 : -1;
        }
    }
}
