﻿using System;
using System.Runtime.Serialization;
using UnityEngine;

namespace Implementation.Data
{
    /// <summary>
    /// Contains implementation of <see cref="IMovementData"/>.
    /// </summary>
    [Serializable]
    public class MovementData : IMovementData
    {
        /// <inheritdoc />
        public string Id { get; set; }

        /// <inheritdoc/>
        public float HorizontalMovement { get; set; }

        /// <inheritdoc/>
        public float GravityEqualizator { get; set; }

        /// <inheritdoc/>
        public float Gravity { get; set; }

        /// <inheritdoc/>
        public float JumpHeightMultiplicator { get; set; }

        /// <inheritdoc/>
        public bool IsInAir { get; set; }

        /// <inheritdoc/>
        public float MovementSpeed { get; set; }
    }
}
