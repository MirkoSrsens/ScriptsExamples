﻿using System;
using System.Collections.Generic;

namespace Implementation.Data
{
    [Serializable]
    public class WholeDialogData : IWholeDialogBoxData
    {
        /// <inheritdoc />
        public string Id { get; set; }

        public Dictionary<int, ISingleDialogData> Dialog { get; set; }

        public WholeDialogData()
        {
            this.Dialog = new Dictionary<int, ISingleDialogData>();
        }
    }
}
