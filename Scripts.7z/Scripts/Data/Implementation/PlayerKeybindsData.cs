﻿using UnityEngine;
using System;

namespace Implementation.Data
{
    [Serializable]
    public class PlayerKeybindsData : IPlayerKeybindsData
    {
        /// <inheritdoc />
        public string Id { get; set; }

        /// <inheritdoc />
        public KeyCode KeyboardJump { get; set; }

        /// <inheritdoc />
        public KeyCode KeyboardLeft { get; set; }

        /// <inheritdoc />
        public KeyCode KeyboardRight { get; set; }

        /// <inheritdoc />
        public KeyCode KnockdownKey { get; set; }

        /// <inheritdoc />
        public KeyCode KeyboardPunchKey { get; set; }

        /// <inheritdoc />
        public KeyCode SpellAction1 { get; set; }

        /// <inheritdoc />
        public KeyCode KeyboardStealthKey { get; set; }

        /// <inheritdoc />
        public KeyCode KeyboardUse { get; set; }

        /// <inheritdoc />
        public KeyCode JoystickJump { get; set; }

        /// <inheritdoc />
        public KeyCode JoystickPunchKey { get; set; }

        /// <inheritdoc />
        public KeyCode JoystickStealthKey { get; set; }

        /// <inheritdoc />
        public KeyCode JoystickUse { get; set; }
    }
}
