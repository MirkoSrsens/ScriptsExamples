﻿using System;
using Character.Stats.UI;

namespace Implementation.Data
{
    [Serializable]
    public class CharacterStats : ICharacterStats
    {
        /// <inheritdoc />
        public string Id { get; set; }

        /// <inheritdoc />
        public string Name { get; set; }

        /// <inheritdoc />
        public int CurrentHealth { get; set; }

        /// <inheritdoc />
        public int MaxHealth { get; set; }

        /// <inheritdoc />
        public void AddHealth(int health, string id)
        {
            StatsController.AddStat(General.Enums.PlayerUIStatsForUpdate.Health, id);
            CurrentHealth += health;

            if (CurrentHealth > MaxHealth)
            {
                CurrentHealth = MaxHealth;
            }
        }

        /// <inheritdoc />
        public bool RemoveHealth(int health, string id)
        {
            StatsController.AddStat(General.Enums.PlayerUIStatsForUpdate.Health, id);
            CurrentHealth -= health;

            if (CurrentHealth <= 0)
            {
                return true;
            }
            return false;
        }

        public CharacterStats()
        {
            MaxHealth = 10;
            CurrentHealth = 7;
        }
    }
}
