﻿using General.State;
using UnityEngine;

namespace Implementation.Data
{
    public class GameInformation : IGameInformation
    {
        /// <inheritdoc />
        public Camera Camera { get; set; }

        /// <inheritdoc />
        public GameObject Player { get; set; }

        /// <inheritdoc />
        public StateController PlayerStateController { get; set; }

        /// <inheritdoc />
        public bool StopMovement { get; set; }

        /// <inheritdoc />
        public IInventoryData InventoryData { get; set; }

        public GameInformation()
        {
            Camera = GameObject.FindGameObjectWithTag("MainCamera").GetComponent<Camera>();

            Player = GameObject.Find("Player");

            InventoryData = SaveAndLoadData<IInventoryData>.LoadSpecificData("Inventory");

            if (Player != null)
            {
                PlayerStateController = Player.GetComponent<StateController>();
            }
        }
    }
}
