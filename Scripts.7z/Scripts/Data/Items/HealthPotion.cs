﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Character.Stats;
using UnityEngine;

namespace Data.Items
{
    public class HealthPotion : Item
    {
        public override Item UseItem(Transform objectThatUsesItem)
        {
            var healthStat = objectThatUsesItem.GetComponent<CharacterStatsMono>();

            if(healthStat != null)
            {
                healthStat.AddHealth(3);
            }

            return this;
        }
    }
}
