﻿using System.Collections;
using System.Collections.Generic;
using Character.Stats;
using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using Implementation.Data.Runtime;
using UnityEngine;
using UnityEngine.SceneManagement;

public class CheckpointAutomaticCall : HighPriorityState
{

    [InjectDiContainter]
    private IGameInformation gameInformation { get; set; }

    protected override void Initialization_State()
    {
        base.Initialization_State();
    }

    public override void OnEnter_State()
    {
        base.OnEnter_State();
        FadeInFadeOut.singleton.OnActivation(LoadScene, General.Enums.EffectDirection.FadeOut);
    }

    public override void Update_State()
    {
        if(gameInformation.PlayerStateController.ActiveHighPriorityState is CharacterIsDead)
        {
            controller.SwapState(this);
        }
    }

    public override void WhileActive_State()
    {
        base.WhileActive_State();   
        if (!(gameInformation.PlayerStateController.ActiveHighPriorityState is CharacterIsDead))
        {
            controller.EndState(this);
        }
    }

    private void LoadScene()
    {
        CustomSceneManager.SwapScene(SceneManager.GetActiveScene().name, false);
    }
}
