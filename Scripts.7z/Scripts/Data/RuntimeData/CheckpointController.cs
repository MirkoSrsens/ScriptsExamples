﻿using System.Collections.Generic;
using System.Linq;
using Character.Stats;
using DiContainerLibrary.DiContainer;
using General.State;
using Secret;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace Implementation.Data.Runtime
{
    public class CheckpointController : HighPriorityState
    {
        public static CheckpointController singleton { get; set; }

        /// <summary>
        /// Current active level.
        /// </summary>
        private string CurrentLevel { get; set; }

        /// <summary>
        /// Gets or sets enemy data.
        /// </summary>
        [InjectDiContainter]
        private IGameInformation gameInformation { get; set; }

        /// <summary>
        /// Gets or sets position of checkpoint.
        /// </summary>
        private Vector3 Position { get; set; }

        /// <summary>
        /// Gets or sets all alive enemies.
        /// </summary>
        public List<string> Enemies { get; set; }

        /// <summary>
        /// Gets or sets secrets found.
        /// </summary>
        public List<string> Secrets { get; set; }

        /// <summary>
        /// Gets or sets player stats.
        /// </summary>
        private Stats playerStats { get; set; }

        private void Awake()
        {
            DontDestroyOnLoad(transform);
            if (FindObjectsOfType(GetType()).Length > 1)
            {
                Destroy(gameObject);
            }
        }

        private void Start()
        {
            Enemies = new List<string>();
            DiContainerInitializor.RegisterObject(this);
            singleton = this;
            CurrentLevel = SceneManager.GetActiveScene().name;
            Position = gameInformation.Player.transform.position;
            SceneManager.sceneLoaded += OnLevelFinishedLoading;
        }

        public void LoadCheckpoint()
        {
            if (gameInformation.Player == null) return;
            if(CurrentLevel != SceneManager.GetActiveScene().name) SaveCheckpoint(gameInformation.Player.transform);

            gameInformation.Player.transform.position = Position;
            var allEnemies = GameObject.FindGameObjectsWithTag("Enemy").Where(x => x.GetComponent<CharacterStatsMono>() != null).Select(x => x.GetComponent<CharacterStatsMono>());

            foreach (var enemy in allEnemies)
            {
                if (!Enemies.Contains(enemy.gameObject.name))
                {
                    Destroy(enemy.gameObject);
                }
            }

            var playerCurrentStats = gameInformation.Player.GetComponent<CharacterStatsMono>();
            if (playerCurrentStats != null)
            {
                var stats = gameInformation.Player.GetComponent<CharacterStatsMono>();
                playerCurrentStats.SetHealth(stats.MaxHealth);
            }

            var secretsToDestroy = GameObject.FindGameObjectsWithTag("Secret").Where(x => !Secrets.Contains(x.gameObject.name)).ToList();

            secretsToDestroy.ForEach(x => SecretCounter.SecretFound(x.name));
            secretsToDestroy.ForEach(x => Destroy(x));

        }

        public void SaveCheckpoint(Transform checkPoint)
        {
            if (gameInformation.Player == null || Position == checkPoint.position) return;
            CurrentLevel = SceneManager.GetActiveScene().name;

            Position = checkPoint.position;

            Enemies = GameObject.FindGameObjectsWithTag("Enemy").Where(x => x.GetComponent<CharacterStats>() != null).Select(x => x.gameObject.name).ToList();
            Secrets = GameObject.FindGameObjectsWithTag("Secret").Select(x => x.gameObject.name).ToList();

            var stats = gameInformation.Player.GetComponent<CharacterStatsMono>();
            playerStats = new Stats()
            {
                CurrentHealth = stats.CurrentHealth,
            };
        }

        private void OnLevelFinishedLoading(Scene scene, LoadSceneMode mode)
        {
            DiContainerInitializor.RegisterObject(this);

            if (gameInformation.Player == null)
            {
                SceneManager.sceneLoaded -= OnLevelFinishedLoading;
                Destroy(this);
            }
            else
            {
                LoadCheckpoint();
            }
        }
    }
}
