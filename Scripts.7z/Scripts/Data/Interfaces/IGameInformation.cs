﻿using General.State;
using UnityEngine;

namespace Implementation.Data
{
    public interface IGameInformation
    {
        /// <summary>
        /// Gets or sets camera object.
        /// </summary>
        Camera Camera { get; set; }

        /// <summary>
        /// Gets or sets player object.
        /// </summary>
        GameObject Player { get; set; }

        /// <summary>
        /// Gets or sets player state controller.
        /// </summary>
        StateController PlayerStateController { get; set; }

        /// <summary>
        /// Gets or sets inventory data.
        /// </summary>
        IInventoryData InventoryData { get; set; }

        /// <summary>
        /// Gets or sets value indicating weather dialog is active or not.
        /// </summary>
        bool StopMovement { get; set; }
    }
}
