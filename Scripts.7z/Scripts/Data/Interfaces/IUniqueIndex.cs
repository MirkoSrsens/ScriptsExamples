﻿namespace Implementation.Data
{
    public interface IUniqueIndex
    {
        /// <summary>
        /// Gets or sets unique indexer.
        /// </summary>
        string Id { get; set; }
    }
}
