﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Assets.Scripts.Data.Interfaces
{
    public interface SpecialEffects
    {
        FadeInFadeOut fadeInFadeOut { get; set; }
    }
}
