﻿using System.Collections.Generic;
using System.Linq;
using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Custom;
using Implementation.Data;
using UnityEngine;

public class OnTriggerAtivate : HighPriorityState
{
    [InjectDiContainter]
    private IGameInformation gameInformation { get; set; }

    public List<GameObject> objectsToActivate;

    public override void OnEnter_State()
    {
        base.OnEnter_State();
        foreach(var item in objectsToActivate)
        {
            item.GetComponentsInChildren<IActivate>().ToList().ForEach(x => x.Activate());
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        controller.SwapState(this);
    }
}
