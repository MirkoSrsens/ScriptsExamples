﻿namespace Implementation.Custom
{
    public interface IActivate
    {
        void Activate();
    }
}
