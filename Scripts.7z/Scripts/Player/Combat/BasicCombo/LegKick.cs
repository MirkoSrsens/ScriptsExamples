﻿using System.Linq;
using Character.Stats;
using Enemy.State;
using General.State;
using Player.Other;
using UnityEngine;

namespace Player.Mechanic.Combat
{
    public class LegKick : PlayerCombatState
    {
        protected override void Initialization_State()
        {
            base.Initialization_State();
            Priority = 16;
        }

        public override void OnEnter_State()
        {
            base.OnEnter_State();
            var enemies = physicsOverlap.Box(transform, RangeOfAttack, RangeOfAttack / 2).Where(x => x.GetComponent<CharacterTakeDamage>() != null && !(x.GetComponent<StateController>().ActiveHighPriorityState is CharacterIsDead)).Select(x => x.GetComponent<CharacterTakeDamage>()).ToList();

            //Get closest enemy.
            var target = enemies.FirstOrDefault(x => Vector2.Distance(x.transform.position, transform.position) == enemies.Min(y => Vector2.Distance(y.transform.position, transform.position)));

            if (target != null)
            {
                target.TakeDamage(Damage);
            }

            StartCoroutine(AttackColdown());
        }
    }
}
