﻿using System.Collections;
using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using UnityEngine;

namespace Player.Mechanic.Combat
{
    public class PlayerCombatState : StateForMechanics
    {
        /// <summary>
        /// Defines damage of punch.
        /// </summary>
        public int Damage;

        /// <summary>
        /// Defines range of attack.
        /// </summary>
        public float RangeOfAttack;

        /// <summary>
        /// Gets or sets physics overlap.
        /// </summary>
        [InjectDiContainter]
        protected IPhysicsOverlap physicsOverlap { get; set; }

        /// <summary>
        /// Defines cooldown of the attack. Attack is over when animation ends.
        /// </summary>
        /// <returns>Yield.</returns>
        protected IEnumerator AttackColdown()
        {
            yield return new WaitUntil(() => { return designController.animationController.IsAnimationOver(this); });
            controller.EndState(this);
        }
    }
}
