﻿using System.Collections;
using General.State;
using UnityEngine;

public class PlayerIdleCombatStance : StateForMovement
{
    private IEnumerator stanceStandTimer { get; set; }

    protected override void Initialization_State()
    {
        base.Initialization_State();
        Priority = -9;
    }
    public override void OnEnter_State()
    {
        stanceStandTimer = StanceStandTimer();
        base.OnEnter_State();
        StartCoroutine(stanceStandTimer);
    }

    public override void WhileActive_State()
    {
        base.WhileActive_State();
        rigBody.velocity = Vector2.zero;
    }

    public override void OnExit_State()
    {
        base.OnExit_State();
        StopCoroutine(stanceStandTimer);
    }

    private IEnumerator StanceStandTimer()
    {
        yield return new WaitForSeconds(5);
        controller.EndState(this);
    }
}
