﻿using System.Collections.Generic;
using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using UnityEngine;

namespace Player.Mechanic.Combat
{
    public class PlayerCombatController : StateForMechanics
    {
        /// <summary>
        /// Gets or sets key binds.
        /// </summary>
        [InjectDiContainter]
        private IPlayerKeybindsData keyBinds { get; set; }

        /// <summary>
        /// Defines Combo.
        /// </summary>
        public List<State> AttackStates;

        /// <summary>
        /// Gets or sets combo index.
        /// </summary>
        private int ComboIndex { get; set; }

        /// <summary>
        /// Gets or sets last active state for mechanic.
        /// </summary>
        private StateForMovement lastStateForMovement { get; set; }

        protected override void Initialization_State()
        {
            base.Initialization_State();
            keyBinds = SaveAndLoadData<IPlayerKeybindsData>.LoadSpecificData("Keybinds");
            Priority = 15;
            ComboIndex = 0;
        }

        public override void OnEnter_State()
        {
            if(!(lastStateForMovement is PlayerCombatMovement))
            {
                ComboIndex = 0;
            }
            controller.SwapState(AttackStates[ComboIndex % AttackStates.Count]);
            ComboIndex++;
        }

        public override void Update_State()
        {
            base.Update_State();

            lastStateForMovement = controller.ActiveStateMovement;
            if ((Input.GetKeyDown(keyBinds.KeyboardPunchKey) && controller.ActiveStateMechanic != this))
            {
                controller.SwapState(this);
            }
        }

        public override void OnExit_State()
        {
        }
    }
}
