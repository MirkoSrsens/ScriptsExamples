﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Data.Items;
using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using UnityEngine;

namespace Assets.Scripts.Characters.Player.Other
{
    public class PlayerPickUpItem : HighPriorityState
    {
        /// <summary>
        /// Gets or sets player key binds;
        /// </summary>
        [InjectDiContainter]
        protected IPlayerKeybindsData keybinds { get; set; }

        /// <summary>
        /// Gets or sets player key binds;
        /// </summary>
        [InjectDiContainter]
        protected IGameInformation gameInformation { get; set; }

        protected override void Initialization_State()
        {
            base.Initialization_State();
            keybinds = SaveAndLoadData<IPlayerKeybindsData>.LoadSpecificData("Keybinds");
        }

        private void OnTriggerStay2D(UnityEngine.Collider2D collision)
        {
            if (collision.gameObject.tag == "Item" && Input.GetKeyDown(keybinds.KeyboardUse))
            {
                var itemComponent = collision.GetComponent<Item>();

                var addedSuccesfully = gameInformation.InventoryData.AddItemToInventory(itemComponent);

                if(addedSuccesfully)
                {
                    Destroy(collision.gameObject);
                }
            }
        }
    }
}
