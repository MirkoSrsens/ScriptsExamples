﻿using General.State;
using Player.Movement;
using UnityEngine;

namespace Player.Other
{
    public class PlayerGravity : StateForMovement
    {
        /// <summary>
        /// Defines tag that enables player to jump.
        /// </summary>
        public const string ObjectsThatEnableJump = "Ground";

        /// <summary>
        /// Gets or sets object collision count.
        /// </summary>
        public static int CollisionCount { get; set; }

        protected override void Initialization_State()
        {
            base.Initialization_State();
        }

        public override void OnEnter_State()
        {
            base.OnEnter_State();
        }

        public override void Update_State()
        {
            if (rigBody.bodyType != RigidbodyType2D.Static)
            {
                rigBody.velocity -= new Vector2(0, MovementData.GravityEqualizator * MovementData.Gravity * Time.deltaTime);
            }

            if(CollisionCount == 0)
            {
                controller.SwapState(this);
            }
        }

        public override void WhileActive_State()
        {
            base.WhileActive_State();
            if(CollisionCount > 0)
            {
                controller.EndState(this);
            }
        }
    }
}
