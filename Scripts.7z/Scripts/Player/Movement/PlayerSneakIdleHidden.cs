﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DiContainerLibrary.DiContainer;
using Implementation.Data;
using Player.Movement;

namespace Assets.Scripts.Characters.Player.Movement
{
    public class PlayerSneakIdleHidden : PlayerSneakIdle
    {
        private bool IsHidingPossible;

        protected override void Initialization_State()
        {
            base.Initialization_State();
            IsHidingPossible = false;
            Priority = 31;
        }

        public override void Update_State()
        {
            if (!IsHidingPossible) return;
            base.Update_State();
        }

        public void OnTriggerEnter2D(UnityEngine.Collider2D collision)
        {
            if(collision.gameObject.tag == "Hide")
            {
                IsHidingPossible = true;
            }
        }

        public void OnTriggerExit2D(UnityEngine.Collider2D collision)
        {
            if (collision.gameObject.tag == "Hide")
            {
                IsHidingPossible = false;
            }
        }
    }
}
