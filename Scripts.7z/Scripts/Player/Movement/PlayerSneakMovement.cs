﻿using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using UnityEngine;

namespace Player.Movement
{
    public class PlayerSneakMovement : StateForMovement
    {
        /// <summary>
        /// Gets or sets player key binds;
        /// </summary>
        [InjectDiContainter]
        protected IPlayerKeybindsData keybinds { get; set; }
        private const float OffsetOnY = -0.5f;
        private const float SizeOfY = 0.8f;
        private float OriginalOffsetOnY;
        private float OriginalSizeOfY;

        private CapsuleCollider2D capsuleColliders;
        protected RaycastHit2D hit;

        protected override void Initialization_State()
        {
            base.Initialization_State();
            Priority = 31;
            capsuleColliders = GetComponent<CapsuleCollider2D>();
            OriginalOffsetOnY = capsuleColliders.offset.y;
            OriginalSizeOfY = capsuleColliders.size.y;

            keybinds = SaveAndLoadData<IPlayerKeybindsData>.LoadSpecificData("Keybinds");
        }

        public override void OnEnter_State()
        {
            base.OnEnter_State();
            capsuleColliders.offset = new Vector2(capsuleColliders.offset.x, OffsetOnY);
            capsuleColliders.size = new Vector2(capsuleColliders.size.x, SizeOfY);
            MovementData.MovementSpeed /= 2;
        }

        public override void Update_State()
        {
            MovementData.HorizontalMovement = (Input.GetKey(keybinds.KeyboardRight) ? 1 : 0) + (Input.GetKey(keybinds.KeyboardLeft) ? -1 : 0);
            // 1024 == Enviroment
            hit = Physics2D.Raycast(transform.position, Vector2.up, 1f, 1024);

            if(MovementData.HorizontalMovement != 0)
            {
                if (hit.transform != null || Input.GetKey(KeyCode.LeftShift))
                {
                    controller.SwapState(this);
                }
            }
        }

        public override void WhileActive_State()
        {
            if (MovementData.HorizontalMovement == 0)
            {
                controller.EndState(this);
                return;
            }

            rigBody.gameObject.transform.localScale = new Vector3(MovementData.HorizontalMovement, 1, 1);
            rigBody.velocity = new Vector2(MovementData.HorizontalMovement * MovementData.MovementSpeed, rigBody.velocity.y);
        }

        public override void OnExit_State()
        {
            base.OnExit_State();
            if(hit.transform == null)
            {
                capsuleColliders.offset = new Vector2(capsuleColliders.offset.x, OriginalOffsetOnY);
                capsuleColliders.size = new Vector2(capsuleColliders.size.x, OriginalSizeOfY);
            }
            MovementData.MovementSpeed *= 2;
        }
    }
}
