﻿using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using UnityEngine;

namespace Player.Movement
{
    [RequireComponent(typeof(PlayerJump))]
    public class PlayerMovement : StateForMovement
    {
        /// <summary>
        /// Gets or sets player key binds;
        /// </summary>
        [InjectDiContainter]
        protected IPlayerKeybindsData keybinds { get; set; }

        protected override void Initialization_State()
        {
            base.Initialization_State();
            Priority = -5;
            keybinds = SaveAndLoadData<IPlayerKeybindsData>.LoadSpecificData("Keybinds");
        }

        public override void Update_State()
        {
            MovementData.HorizontalMovement = (Input.GetKey(keybinds.KeyboardRight) ? 1 : 0) + (Input.GetKey(keybinds.KeyboardLeft) ? -1 : 0);

            if (MovementData.HorizontalMovement != 0)
            {
                controller.SwapState(this);
            } 
        }

        public override void WhileActive_State()
        {
            if (MovementData.HorizontalMovement == 0)
            {
                rigBody.velocity = new Vector2(0, rigBody.velocity.y);
                controller.EndState(this);
                return;
            }

            rigBody.gameObject.transform.localScale = new Vector3(MovementData.HorizontalMovement, 1, 1);
            rigBody.velocity = new Vector2(MovementData.HorizontalMovement * MovementData.MovementSpeed, rigBody.velocity.y);
        }
    }
}
