﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RunParticleEffect : MonoBehaviour
{
    private ParticleSystem customParticleSystem;

    public void FireParticlesFrontFoot()
    {
        customParticleSystem = GameObject.Find("ParticleSystemFrontFoot").GetComponent<ParticleSystem>();
        customParticleSystem.Play();
    }

    public void FireParticlesBackFoot()
    {
        customParticleSystem = GameObject.Find("ParticleSystemBackFoot").GetComponent<ParticleSystem>();
        customParticleSystem.Play();
    }
}
