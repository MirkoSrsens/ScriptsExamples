﻿using UnityEngine;

namespace Player.Movement
{
    public class PlayerSneakIdle : PlayerSneakMovement
    {
        protected override void Initialization_State()
        {
            base.Initialization_State();
            Priority = 30;
        }

        public override void OnEnter_State()
        {
            base.OnEnter_State();
            rigBody.constraints = RigidbodyConstraints2D.FreezePositionX | RigidbodyConstraints2D.FreezeRotation;
        }

        public override void Update_State()
        {
            // 1024 == Enviroment
            hit = Physics2D.Raycast(transform.position, Vector2.up, 1f, 1024);

            if (hit.transform != null || Input.GetKey(KeyCode.LeftShift))
            {
                controller.SwapState(this);
            }
        }

        public override void WhileActive_State()
        {
            if (!Input.GetKey(KeyCode.LeftShift) && hit.transform == null)
            {
                controller.EndState(this);
            }
        }

        public override void OnExit_State()
        {
            base.OnExit_State();
            rigBody.constraints = RigidbodyConstraints2D.FreezeRotation;
        }
    }
}
