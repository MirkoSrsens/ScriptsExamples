﻿using DiContainerLibrary.DiContainer;
using General.State;
using Implementation.Data;
using Player.Other;
using UnityEngine;

namespace Player.Movement
{
    /// <summary>
    /// Class that defines state of jumping.
    /// </summary>
    public class PlayerJump : StateForMovement
    {
        /// <summary>
        /// Gets or sets player key binds;
        /// </summary>
        [InjectDiContainter]
        protected IPlayerKeybindsData keybinds;

        protected override void Initialization_State()
        {
            base.Initialization_State();
            Priority = 0;
            keybinds = SaveAndLoadData<IPlayerKeybindsData>.LoadSpecificData("Keybinds");
        }

        public override void OnEnter_State()
        {
            base.OnEnter_State();
            rigBody.velocity = new Vector2(rigBody.velocity.x, MovementData.Gravity* MovementData.JumpHeightMultiplicator*1.3f);
        }

        public override void Update_State()
        {
            MovementData.HorizontalMovement = (Input.GetKey(keybinds.KeyboardRight) ? 1 : 0) + (Input.GetKey(keybinds.KeyboardLeft) ? -1 : 0);

            if (PlayerGravity.CollisionCount != 0 && controller.ActiveStateMovement != this && Input.GetKeyDown(keybinds.KeyboardJump))
            {               
                controller.SwapState(this);
            }
        }

        public override void WhileActive_State()
        {
            if (MovementData.HorizontalMovement != 0)
            {
                rigBody.gameObject.transform.localScale = new Vector3(MovementData.HorizontalMovement, 1, 1);
            }

            rigBody.velocity = new Vector2(MovementData.MovementSpeed* MovementData.HorizontalMovement, rigBody.velocity.y);
        }


        public override void OnExit_State()
        {
            base.OnExit_State();
        }

        public void OnTriggerExit2D(Collider2D collision)
        {
            if (collision.gameObject.tag == PlayerGravity.ObjectsThatEnableJump)
                PlayerGravity.CollisionCount--;
        }

        public void OnTriggerEnter2D(Collider2D collision)
        {
            if (collision.gameObject.tag == PlayerGravity.ObjectsThatEnableJump)
                PlayerGravity.CollisionCount++;

            if (PlayerGravity.CollisionCount > 0)
            {
                controller.EndState(this);
            }
        }
    }
}
